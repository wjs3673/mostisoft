<template>
  <div>
    <button @click="changeJson()">항목 JSON 반환</button>
    <button @click="getJson()">항목 불러오기</button>
    <button @click="reset()">초기화</button>
    <button @click="moveToDetail()">페이지 이동</button>
  </div>
</template>

<script>

export default {
  methods: {
    reset() {
      this.$emit("reset");
    },
    changeJson() {
      this.$emit("changeJson");
    },
    getJson() {
      this.$emit("getJson");
    },
    moveToDetail() {
      this.$emit("moveToDetail");
    },
  },
};
</script>

<style scoped>
button {
  margin-right: auto;
  margin-left: auto;
}
</style>
