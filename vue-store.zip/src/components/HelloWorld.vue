<template>
  <div>
    {{ count }}
    <br />
    {{getCount}}
    <!-- {{ $store.state.count }} -->
    <!-- <br /> -->
    <!-- {{ $store.getters.getCount }} -->
    <br />
    <input type="text" v-model="num" />
    <button @click="clickButton()">버튼</button>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";

export default {
  data() {
    return {
      num: "",
    };
  },
  // mounted(){
  //   alert("");
  // },
  computed: {
    ...mapState({
      count(state) {
        return state.count;
      },
    }),
    ...mapGetters(["getCount"]),
  },
  methods: {
    clickButton() {
      this.$store.dispatch("actionCount", this.num);

      this.num = "";
    },
  },
};
</script>

<style></style>
