<template>
    <div id="layerPopup" v-if="isShow">
      <div>
        <div class="closeBtn">
          <button @click="closePopup()">X</button>
        </div>

        <div v-if="popupValue == '1'">
          <strong>&lt;일괄 수정 &gt;</strong>
        </div>
        <div v-else>
          <strong>&lt;단건 수정 &gt;</strong>
        </div>

        <div class="outerBox">
          <span>변환 전 </span>
          <input v-if="popupValue == '1'" type="text" v-model="before"/>
          <input v-else type="text" v-model="beforeData" style="background-color: #ffaa7c" readonly/>
        </div>
        <div class="outerBox">
          <span>변환 후 </span>
          <input type="text" v-model="after" />
        </div>

        <button v-if="popupValue == '1'" @click="changeAll()">일괄 수정</button>
        <button v-else @click="changeOne()">단건 수정</button>
      </div>
    </div>
</template>

<script>
export default {
  props: ["popupValue", "beforeData", "isShow"],
  data() {
    return {
      before: "",
      after: "",
    };
  },
  methods: {
    changeAll() {
      this.$emit("changeAll", this.before, this.after);
    },
    changeOne() {
      this.$emit("changeOne", this.beforeData, this.after);
    },
    closePopup() {
      this.$emit("closePopup");
    },
  },
};
</script>

<style scoped>
#layerPopup {
  position: fixed;

  left: 50%;

  top: 50%;

  width: 300px;

  /*가로길이 설정은 여기서*/

  margin-left: -10%;

  /*width의 반만큼 음수로*/

  height: 300px;

  /*세로길이 설정은 여기서*/

  margin-top: -150px;

  /*height의 반만큼 음수로*/

  z-index: 1000;

  /*style*/

  background: white;

  border: 1px solid #d1d8dd;

  box-shadow: 0 0 6px 1px rgb(0 0 0 / 30%);

  text-align: center;
}
</style>
