<template>
  <div>
    <h1>Todo List</h1>
    <Header
      :todoList="todoList"
      v-on:todoAdd="todoAdd"
      v-on:selectDel="selectDel"
      v-on:showPopAll="showPopAll"
      v-on:getsearchList="getsearchList"
    ></Header>
    <Popup
      v-on:changeAll="changeAll"
      v-on:changeOne="changeOne"
      v-on:closePopup="closePopup"
      :popupValue="popupValue"
      :beforeData="beforeData"
      :isShow="isShow"
    ></Popup>
    <List
      :todoList="getsearch"
      v-on:todoDel="todoDel"
      v-on:showPopOne="showPopOne"
      v-on:todoComplete="todoComplete"
      v-on:selectAll="selectAll"
    ></List>
    <Footer
      v-on:changeJson="changeJson"
      v-on:getJson="getJson"
      v-on:reset="reset"
      v-on:moveToDetail="moveToDetail"
    ></Footer>
  </div>
</template>

<script>
import Header from "../components/Header.vue";
import List from "../components/List.vue";
import Footer from "../components/Footer.vue";
import Popup from "../components/Popup.vue";
// import { mapState, mapGetters } from "vuex";

export default {
  components: {
    Header,
    List,
    Footer,
    Popup,
  },
  data() {
    return {
      todoList: [],
      popupValue: "",
      beforeData: "",
      searchDate: "",
      isShow: false,
    };
  },
  computed: {
    /**
     * getsearch() : 날짜 검색 결과 보여주기
     */
    getsearch() {
      if (this.searchDate == "") {
        this.$store.dispatch("loadList", this.todoList);
        return this.todoList;
      } else {
        
        return this.todoList.filter((a) => a.date == this.searchDate);
      }
    },
    // ...mapState({
    //   todoList(state) {
    //     return state.todoList;
    //   },
    // }),
    // ...mapGetters(["getTodoList"]),
  },
  methods: {
    /**
     * todoAdd() : 할 일 추가하기
     * @param dataAdd : 날짜 항목
     * @param contentAdd : 내용 항목
     */
    todoAdd(dataAdd, contentAdd) {
      let lastID = 0;

      if (this.todoList.length == 0) {
        lastID = 0;
      } else {
        lastID = parseInt(this.todoList.at(-1).rowId) + 1;
      }

      this.todoList.push({
        rowId: lastID,
        date: dataAdd,
        contents: contentAdd,
        complete: "N",
        checked: false,
      });

      this.$store.dispatch("todoAdd", this.todoList);
    },
    /**
     * todoDel() : 단건 삭제
     * @param rowId : 행 번호
     */
    todoDel(rowId) {
      for (var i = 0; i < this.todoList.length; i++) {
        if (this.todoList[i].rowId == rowId) {
          this.todoList.splice(i, 1);
        }
      }

      this.$store.dispatch("loadList", this.todoList);
    },
    /**
     * selectDel() : 선택 삭제
     */
    selectDel() {
      this.$store.dispatch("selectDel", this.todoList);
    },
    /**
     * showPopAll(): 일괄 수정 팝업 열기
     */
    showPopAll() {
      this.popupValue = "1";
      this.isShow = true;
    },
    /**
     * showPopOne(): 단건 수정 팝업 열기
     */
    showPopOne(rowId) {
      this.isShow = true;

      for (let item of this.todoList) {
        if (item.rowId == rowId) {
          this.beforeData = item.contents;
        }
      }

      this.$store.dispatch("loadList", this.todoList);
      this.popupValue = "0";
    },
    /**
     * closePopup() : 팝업 닫기
     */
    closePopup() {
      this.isShow = false;
    },
    /**
     * reset() : 초기화
     */
    reset() {
      this.todoList = [];
      this.$store.dispatch("reset");
    },
    /**
     * changeAll() : 일괄 수정
     * @param before : 변경 전 contents 값
     * @param after : 변경 후 contents 값
     */
    changeAll(before, after) {
      for (let item of this.todoList) {
        if (item.contents.includes(before)) {
          item.contents = item.contents.replace(before, after);
        }
      }

      this.$store.dispatch("loadList", this.todoList);

      this.isShow = false;
      before = "";
      after = "";
    },
    /**
     * changeOne() : 단건 수정
     * @param before : 변경 전 contents 값
     * @param after : 변경 후 contents 값
     */
    changeOne(before, after) {
      for (let item of this.todoList) {
        if (before == item.contents) {
          item.contents = after;
        }
      }

      this.$store.dispatch("loadList", this.todoList);
      this.isShow = false;
      before = "";
      after = "";
    },
    /**
     * changeJson() : Json 데이터로 반환 alert, 항목 JSON 반환
     */
    changeJson() {
      this.$store.dispatch("changeJson", this.todoList);
    },
    /**
     * todoComplete() : 내용 클릭시 할 일 완료
     * @param complete : 완료 Y/N
     * @param rowId : 행 번호
     */
    todoComplete(complete, rowId) {
      for (let item of this.todoList) {
        if (item.rowId == rowId && complete == "N") {
          item.complete = "Y";
        } else if (item.rowId == rowId && complete == "Y") {
          item.complete = "N";
        }
      }

      this.$store.dispatch("loadList", this.todoList);
    },
    /**
     * getsearchList() : 날짜 검색
     * searchDate : 검색할 날짜
     */
    getsearchList(searchDate) {
      this.searchDate = searchDate;
    },
    /**
     * getJson() : Json 데이터 가져오기, 항목 불러오기 버튼
     * axios get 방식
     */
    getJson() {
      this.$store.dispatch("getJson", this.todoList);
    },
    /**
     * moveToDetail() : 상세 페이지 이동
     */
    moveToDetail() {
      this.$router.push({
        name: "Detail",
        params: {
          todoList: this.todoList.filter((a) => a.complete == "Y"),
        },
      });
    },
    /**
     * selectAll() : 전체 선택
     * selectall : 선택한 값
     */
    selectAll(selectall) {
      for (let index = 0; index < this.todoList.length; index++) {
        const element = this.todoList[index];
        element.checked = selectall;
      }

      this.$store.dispatch("loadList", this.todoList);
    },
  },
};
</script>

<style scoped>
h1 {
  text-align: center;
}
</style>
