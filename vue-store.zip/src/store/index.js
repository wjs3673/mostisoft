import Vue from 'vue';
import Vuex from 'vuex';
import axios from "axios";

Vue.use(Vuex);

export default new Vuex.Store({
  state() {
    return {
      todoList: [],
      searchValue:"0"
    }
  },
  actions: {
    todoAdd({ commit }, todoList) {
      commit('LOAD_LIST', todoList);
    },
    loadList({ commit }, todoList) {
      commit('LOAD_LIST', todoList);
    },
    selectDel({ commit }, todoList) {
      todoList = todoList.filter((a) => a.checked != true);
      commit('LOAD_LIST', todoList);
    },
    reset({ commit }) {
      commit('LOAD_LIST', []);
    },
    changeJson({ commit }, todoList) {
      alert(JSON.stringify(todoList));
      commit('LOAD_LIST', todoList);
    },
    getJson({ commit }, todoList){
      axios
        .get("./Todo.json")
        .then(function (todoJson) {
          for (let item of todoJson.data) {
            todoList.push({
              rowId: item.rowId,
              date: item.date,
              contents: item.contents,
              complete: item.complete,
              checked: false,
            });
          }
        })
        .catch(function (error) {
          console.log("실패");
          console.log(error);
        });

      commit('LOAD_LIST', todoList);
    },
    getSearch({ commit }, todoList, searchDate){
      todoList.filter((a) => a.date == searchDate);
      commit('LOAD_LIST', todoList);
    }
  },
  mutations: {
    LOAD_LIST(state, todoList) {
      state.todoList = todoList;
    },
  },
  getters: {
    getTodoList(state) {
      return state.todoList
    }
  }
})