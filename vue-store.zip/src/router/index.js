import Vue from 'vue';
import VueRouter from 'vue-router';
import Main from '../views/Main.vue';
import Detail from '../views/Detail.vue';

Vue.use(VueRouter);

export default new VueRouter({
// export const router = new VueRouter({
  mode: 'history',
  routes: [
  {
    path: '/',
    component: Main,
    name: 'Main'
  },
  {
    path: '/detail',
    component: Detail,
    name:'Detail',
    props: true
  }
]
})