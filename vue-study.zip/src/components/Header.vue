<template>
  <div>
    <table border="1">
      <tbody>
        <tr>
          <!-- 날짜 selectBox -->
          <select
            name="dateSelect"
            @click="todoSort()"
            v-model="searchValue"
            @change="getsearchList(searchValue)"
          >
            <option value="0">날짜선택</option>
            <option v-for="item in todoSortList" :key="item">
              {{ item }}
            </option>
          </select>
        </tr>
        <tr>
          <td>
            <!-- 날짜 입력란 -->
            <input
              type="text"
              placeholder="yyyy-MM-dd"
              v-model="dateAdd"
              class="datepicker"
              id="datepicker"
            />
          </td>
          <td colspan="2">
            <!-- 일괄 수정 버튼 -->
            <button @click="showPopAll()">일괄 수정</button>
          </td>
        </tr>
        <tr>
          <td>
            <!-- 할 일 입력란 -->
            <input
              type="text"
              placeholder="할 일을 입력해주세요"
              v-model="contentAdd"
            />
          </td>
          <td>
            <!-- 추가 버튼 -->
            <button v-on:click="todoAdd()">추가</button>
          </td>
          <td>
            <!-- 선택 삭제 버튼 -->
            <button @click="selectDel()">선택 삭제</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  props: ["todoList"],
  data() {
    return {
      dateAdd: "",
      contentAdd: "",
      todoSortList: [],
      searchValue: "0",
    };
  },
  methods: {
    todoAdd() {
      this.$emit("todoAdd", this.dateAdd, this.contentAdd);

      this.dateAdd = "";
      this.contentAdd = "";
    },
    todoSort() {
      for (var item of this.todoList) {
        this.todoSortList.push(item.date);
      }
      this.todoSortList = Array.from(new Set(this.todoSortList));
    },
    showPopAll() {
      this.$emit("showPopAll");
    },
    getsearchList(searchDate) {
      this.$emit("getsearchList", searchDate);
    },
    selectDel(){
      this.$emit("selectDel");
    }
  },
};
</script>

<style>
table {
  margin-right: auto;
  margin-left: auto;
}
td{
  padding-left: 15px;
  padding-right: 15px;
}
</style>
