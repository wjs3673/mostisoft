<template>
  <div>
    {{ no }}
    <button v-on:click="getValue()">버튼</button>
  </div>
</template>

<script>
export default {
  props: ["no"],
  methods: {
    getValue() {
      this.$emit("getValue", 100);
    },
  },
};
</script>

<style></style>
