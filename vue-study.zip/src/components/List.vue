<template>
  <div>
    <table border="1">
      <thead>
        <tr>
          <!-- 전체 선택 -->
          <th>
            <input
              type="checkbox"
              v-model="getselectAll"
            />
          </th>
          <th>날짜</th>
          <th colspan="3">내용</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="item in todoList"
          :key="item.key"
          :style="`background-color: ${
            item.complete == `Y` ? `#ffaa7c` : `#ffffff`
          }`"
        >
          <td>
            <input
              type="checkbox"
              name="selectAll"
              v-model="item.checked"
            />
          </td>
          <td>{{ item.date }}</td>
          <!-- 클릭시 완료됨 표시 -->
          <td @click="todoComplete(item.complete, item.rowId)">
            {{ item.contents }}
          </td>
          <!-- 단건 삭제 -->
          <td><button @click="todoDel(item.rowId)">X</button></td>
          <!-- 단건 수정 -->
          <td><button @click="showPopOne(item.rowId)">수정</button></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectall: "",
    };
  },
  props: {
    todoList: [],
  },
  computed: {
    getselectAll: {
      get() {
        let checkValue = this.todoList.filter(a => a.checked == true).map(item => item.rowId);

        if (this.todoList.length !=0 && checkValue.length == this.todoList.length) {
          return true;
        } else {
          return false;
        }
      },
      set(value) {
        this.selectall = value;
        this.$emit("selectAll", this.selectall);
      },
    },
  },
  methods: {
    todoDel(rowId) {
      this.$emit("todoDel", rowId);
    },
    showPopOne(rowId) {
      this.$emit("showPopOne", rowId);
    },
    todoComplete(complete, rowId) {
      this.$emit("todoComplete", complete, rowId);
    },
  },
};
</script>

<style scoped>
table {
  margin-right: auto;
  margin-left: auto;
}
td,
th {
  padding-left: 50px;
  padding-right: 50px;
}
</style>
