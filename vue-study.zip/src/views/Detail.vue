<template>
  <div>
    <select v-model="orderSelect" @change="orderChange()">
      <option value="0">기능 선택</option>
      <option value="1">오름차순</option>
      <option value="2">내림차순</option>
    </select>
    <table border="1">
      <thead>
        <tr>
          <th>날짜</th>
          <th>내용</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in todoList" :key="item.key">
          <td>{{ item.date }}</td>
          <td>{{ item.contents }}</td>
        </tr>
      </tbody>
    </table>
    <button @click="moveToMain()">돌아가기</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      orderSelect: "0",
    };
  },
  name: "Detail",
  props: {
    todoList: [],
  },
  methods: {
    orderChange() {
      if (this.orderSelect == "1") {
        this.highSort();
      } else if (this.orderSelect == "2") {
        this.lowSort();
      }
    },
    // 오름차순
    highSort() {
      this.todoList.sort((a, b) => {
        if (a.date > b.date) return 1;
        if (a.date < b.date) return -1;
        return 0;
      });
    },
    // 내림차순
    lowSort() {
      this.todoList.sort((a, b) => {
        if (a.date < b.date) return 1;
        if (a.date > b.date) return -1;
        return 0;
      });
    },
    moveToMain(){
      this.$router.push({
        name : "Main"
      })
    }
  },
};
</script>

<style></style>
