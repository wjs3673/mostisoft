<template>
  <div>
    <!-- {{ hello }} -->
    {{ text }}
  </div>
</template>

<script>
export default {
  data() {
    return {
      hello: "안녕하세요.",
      text: "",
    };
  },
  beforeCreate() {
    this.text += "beforeCreate /";
  },
  created() {
    this.text += "created /";
  },
  beforeMount() {
    this.text += "beforeMount /";
  },
  mounted() {
    this.text += "mounted /";
  },
  beforeDestroy() {
    this.text += "beforeDestroy /";
  },
  destroyed() {
    this.text += "destroyed /";
  },
};
</script>

<style>
</style>