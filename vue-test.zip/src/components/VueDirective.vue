<template>
  <div>
    <!-- #region v-text -->
    <label v-text="text"></label>
    <!-- #endregion v-text -->

    <!-- #region v-html -->
    <p v-html="html"></p>
    <!-- #endregion v-html -->

    <!-- #region v-bind -->
    <p :style="style">은승이 바보</p>
    <!-- #endregion v-bind -->

    <!-- #region v-show -->
    <div v-show="false">v-show</div>
    <!-- #endregion v-show -->

    <!-- #region v-if -->
    <div v-if="boolean">v-if</div>
    <div v-else>v-else</div>
    <!-- #endregion v-if -->

    <!-- #region v-for -->
    <ul>
      <li v-for="item in list" :key="item.key">
        <button v-on:click="clickButton(item)">{{ item.value }}</button>
      </li>
    </ul>
    <!-- #endregion v-for -->

    <!-- #region v-pre -->
    <div v-pre>
      {{ html }}
    </div>
    <!-- #endregion v-pre -->

    <!-- #region v-on -->
    <!-- <button v-on:click="clickButton()">버튼</button> -->
    <!-- <button v-on:click="clickButton('버튼입니다.')">버튼</button> -->
    <button @click="clickButton('버튼입니다.')">버튼</button>
    <!-- #endregion v-on -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      text: "텍스트",
      html: "<label>v-html test</label>",
      style: "background-color : red;",
      boolean: true,
      list: [
        {
          key: 1,
          value: "a",
        },
        {
          key: 2,
          value: "b",
        },
        {
          key: 3,
          value: "c",
        },
      ],
    };
  },
  methods: {
    clickButton(item) {
      // alert("버튼 클릭");
      // alert(txt);
      alert(`${item.key} / ${item.value}`);
    },
  },
};
</script>

<style>
</style>