<template>
  <div>
    <h1>Vue Templete</h1>
    <input type="text" v-model="text" />
    <button @click="clickButton()">버튼</button>

    <!-- <input type="checkbox" value="1" v-model="checkbox"> One
    <input type="checkbox" value="2" v-model="checkbox"> Two -->

    <!-- #region conputed -->
    <br />
    {{ computeMessage }}
    <!-- #endregion conputed -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      message: "안녕하세요.",
      text: "",
      checkbox: "",
    };
  },
  // watch는 개발할 때 잘 안 쓴다, 진짜 필요할 때 아니면 안 쓴다.
  // 사유 : 디버깅이 힘들다
  watch: {
    text(newValue, oldValue) {
      this.setMessage(newValue, oldValue);
    },
  },
  computed: {
    computeMessage() {
      return `${this.text} 반갑습니다.`;
    },
  },
  methods: {
    clickButton() {},
    setMessage(newValue, oldValue) {
      console.log(`newValue: ${newValue}`);
      console.log(`oldValue: ${oldValue}`);
    },
  },
};
</script>

<style></style>
