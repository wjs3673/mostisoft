<template>
  <div>
    <!-- 테이블로 Todo List -->
    <!-- 1. 리스트를 그린다. -->
    <!-- 2. 단건 삭제 버튼도 그린다. -->
    <table>
      <thead>
        <tr>
          <input type="text" placeholder="yyyy-MM-dd" v-model="dateAdd" />
        </tr>
        <tr>
          <td><input type="text" v-model="contentAdd" /></td>
          <!-- 4. 등록(추가) 이벤트도 만든다. -->
          <td><button @click="todoAdd()">추가</button></td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>날짜</th>
          <th>내용</th>
          <th>삭제</th>
          <th>완료여부</th>
        </tr>
        <tr v-for="item in list" :key="item.key">
          <td>{{ item.date }}</td>
          <td>{{ item.contents }}</td>
          <!-- 3. 삭제 버튼을 기능이 되게 함수를 만든다. -->
          <td><button @click="todoDel(item.rowId)">X</button></td>
          <td>{{ item.complete }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dateAdd: "",
      contentAdd: "",
      list: [
        {
          rowId: 1,
          date: "2022-10-10",
          contents: "내용1",
          complete: "Y",
        },
        {
          rowId: 2,
          date: "2022-10-11",
          contents: "내용2",
          complete: "N",
        },
        {
          rowId: 3,
          date: "2022-10-11",
          contents: "내용3",
          complete: "N",
        },
        {
          rowId: 4,
          date: "2022-10-12",
          contents: "내용4",
          complete: "N",
        },
        {
          rowId: 5,
          date: "2022-10-13",
          contents: "내용5",
          complete: "Y",
        },
      ],
    };
  },
  methods: {
    todoAdd() {
      if (this.dateAdd == "" || this.contentAdd == "") {
        alert("할 일을 입력하세요 !");
      } else {
        this.list.push({
          rowId: this.list.length + 1,
          date: this.dateAdd,
          contents: this.contentAdd,
          complete: "N",
        });

        this.dateAdd = "";
        this.contentAdd = "";
      }
    },
    todoDel(id) {
      for (var i = 0; i < this.list.length; i++) {
        if (this.list[i].rowId == id) {
          this.list.splice(i, 1);
        }
      }
    },
  },
};
</script>

<style></style>
